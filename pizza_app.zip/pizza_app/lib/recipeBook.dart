import 'package:flutter/material.dart';

class Recipebook extends StatefulWidget {
  const Recipebook({super.key});

  @override
  State<Recipebook> createState() => _RecipebookState();
}

class _RecipebookState extends State<Recipebook> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
